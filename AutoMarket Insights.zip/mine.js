// JavaScript source code
alert('你好呀，朋友')